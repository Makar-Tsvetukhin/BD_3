﻿public class AppSettings
{
    public string AppName { get; set; }
    public string Version { get; set; }
    public string Environment { get; set; }
}
